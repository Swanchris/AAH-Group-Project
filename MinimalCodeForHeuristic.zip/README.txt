This has been tested to work on python 3.8.6. There may be issues installing some of the following packages in python 3.9.

Dependencies for heuristic solver:
	numpy (may require visual studio build tools)
	numba
	sklearn

These packages were installed with:
	pip3 install numpy
	pip3 install numba
	pip3 install sklearn

An example of how we have used this solver:
	python __main__.py "testInstance.txt"

A feasible solution is given in the form of a list of sets of job indexes.
Importantly, the job indexes given in the feasible solution range from 0 to n-1, and so job 0 means the first job described in the instance file.

The makespan (described in the output file as "objective value") of the feasible solution is also provided.

The total time elapsed is provided, as well as the time required to find the best solution that is found during the solving process (i.e. time required to find the output feasible solution).
